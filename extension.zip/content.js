(function () {
    function tick() {
        const video = document.querySelector('video');
        if (!video) return;

        const isAd = !!document.querySelector('.ad-showing');

        if (isAd) {
            if (video.duration && video.currentTime < video.duration - 0.1) {
                video.currentTime = video.duration;
            }
            video.muted = true;

            const selectors = [
                '.ytp-skip-ad-button',
                '.ytp-ad-skip-button',
                '.ytp-ad-skip-button-modern',
                '.ytp-ad-skip-button-slot button',
            ];
            for (const sel of selectors) {
                const btn = document.querySelector(sel);
                if (btn) { btn.click(); break; }
            }

            for (const btn of document.querySelectorAll('button')) {
                if (btn.offsetParent === null) continue;
                const text = btn.textContent || '';
                if (text.includes('スキップ') || text.includes('Skip')) {
                    btn.click(); break;
                }
            }
        } else {
            if (video.muted) video.muted = false;
        }
    }

    setInterval(tick, 300);
})();
